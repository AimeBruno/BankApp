﻿namespace FinalProject
{
    partial class AccountForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BankAccountsGroupBox = new System.Windows.Forms.GroupBox();
            this.savingsAccountBalanceLabel = new System.Windows.Forms.Label();
            this.checkingAccountBalanceLabel = new System.Windows.Forms.Label();
            this.savingsAccountLabel = new System.Windows.Forms.Label();
            this.checkingAccountLabel = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.creditCardGourpBox = new System.Windows.Forms.GroupBox();
            this.creditCardLabel = new System.Windows.Forms.Label();
            this.AccountMenuStrip = new System.Windows.Forms.MenuStrip();
            this.myAccountsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userProfileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transactionHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.financeNewsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.storeLocatorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TransactionsGroupBox = new System.Windows.Forms.GroupBox();
            this.amountTextBox = new System.Windows.Forms.TextBox();
            this.amountLabel = new System.Windows.Forms.Label();
            this.transactionErrorLabel = new System.Windows.Forms.Label();
            this.submitButton = new System.Windows.Forms.Button();
            this.toLabel = new System.Windows.Forms.Label();
            this.accountToComboBox = new System.Windows.Forms.ComboBox();
            this.fromLabel = new System.Windows.Forms.Label();
            this.accountFromComboBox = new System.Windows.Forms.ComboBox();
            this.loansLabel = new System.Windows.Forms.Label();
            this.loansGroupBox = new System.Windows.Forms.GroupBox();
            this.fundsDataSet = new FinalProject.FundsDataSet();
            this.fundsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fundsTableAdapter = new FinalProject.FundsDataSetTableAdapters.FundsTableAdapter();
            this.tableAdapterManager = new FinalProject.FundsDataSetTableAdapters.TableAdapterManager();
            this.recordDataSet = new FinalProject.RecordDataSet();
            this.recordBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.recordTableAdapter = new FinalProject.RecordDataSetTableAdapters.RecordTableAdapter();
            this.tableAdapterManager1 = new FinalProject.RecordDataSetTableAdapters.TableAdapterManager();
            this.BankAccountsGroupBox.SuspendLayout();
            this.creditCardGourpBox.SuspendLayout();
            this.AccountMenuStrip.SuspendLayout();
            this.TransactionsGroupBox.SuspendLayout();
            this.loansGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fundsDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fundsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.recordDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.recordBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // BankAccountsGroupBox
            // 
            this.BankAccountsGroupBox.Controls.Add(this.savingsAccountBalanceLabel);
            this.BankAccountsGroupBox.Controls.Add(this.checkingAccountBalanceLabel);
            this.BankAccountsGroupBox.Controls.Add(this.savingsAccountLabel);
            this.BankAccountsGroupBox.Controls.Add(this.checkingAccountLabel);
            this.BankAccountsGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BankAccountsGroupBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.BankAccountsGroupBox.Location = new System.Drawing.Point(11, 49);
            this.BankAccountsGroupBox.Name = "BankAccountsGroupBox";
            this.BankAccountsGroupBox.Size = new System.Drawing.Size(449, 100);
            this.BankAccountsGroupBox.TabIndex = 0;
            this.BankAccountsGroupBox.TabStop = false;
            this.BankAccountsGroupBox.Text = "Bank accounts";
            // 
            // savingsAccountBalanceLabel
            // 
            this.savingsAccountBalanceLabel.AutoSize = true;
            this.savingsAccountBalanceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.savingsAccountBalanceLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.savingsAccountBalanceLabel.Location = new System.Drawing.Point(348, 61);
            this.savingsAccountBalanceLabel.Name = "savingsAccountBalanceLabel";
            this.savingsAccountBalanceLabel.Size = new System.Drawing.Size(0, 18);
            this.savingsAccountBalanceLabel.TabIndex = 3;
            // 
            // checkingAccountBalanceLabel
            // 
            this.checkingAccountBalanceLabel.AutoSize = true;
            this.checkingAccountBalanceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkingAccountBalanceLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.checkingAccountBalanceLabel.Location = new System.Drawing.Point(348, 30);
            this.checkingAccountBalanceLabel.Name = "checkingAccountBalanceLabel";
            this.checkingAccountBalanceLabel.Size = new System.Drawing.Size(0, 18);
            this.checkingAccountBalanceLabel.TabIndex = 2;
            // 
            // savingsAccountLabel
            // 
            this.savingsAccountLabel.AutoSize = true;
            this.savingsAccountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.savingsAccountLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.savingsAccountLabel.Location = new System.Drawing.Point(6, 61);
            this.savingsAccountLabel.Name = "savingsAccountLabel";
            this.savingsAccountLabel.Size = new System.Drawing.Size(117, 18);
            this.savingsAccountLabel.TabIndex = 1;
            this.savingsAccountLabel.Text = "Savings account";
            // 
            // checkingAccountLabel
            // 
            this.checkingAccountLabel.AutoSize = true;
            this.checkingAccountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkingAccountLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.checkingAccountLabel.Location = new System.Drawing.Point(6, 27);
            this.checkingAccountLabel.Name = "checkingAccountLabel";
            this.checkingAccountLabel.Size = new System.Drawing.Size(127, 18);
            this.checkingAccountLabel.TabIndex = 0;
            this.checkingAccountLabel.Text = "Checking account";
            // 
            // creditCardGourpBox
            // 
            this.creditCardGourpBox.Controls.Add(this.creditCardLabel);
            this.creditCardGourpBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.creditCardGourpBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.creditCardGourpBox.Location = new System.Drawing.Point(11, 155);
            this.creditCardGourpBox.Name = "creditCardGourpBox";
            this.creditCardGourpBox.Size = new System.Drawing.Size(449, 115);
            this.creditCardGourpBox.TabIndex = 1;
            this.creditCardGourpBox.TabStop = false;
            this.creditCardGourpBox.Text = "Credit Cards";
            // 
            // creditCardLabel
            // 
            this.creditCardLabel.AutoSize = true;
            this.creditCardLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.creditCardLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.creditCardLabel.Location = new System.Drawing.Point(6, 46);
            this.creditCardLabel.Name = "creditCardLabel";
            this.creditCardLabel.Size = new System.Drawing.Size(401, 18);
            this.creditCardLabel.TabIndex = 0;
            this.creditCardLabel.Text = "There is no current credit card associated with your account";
            // 
            // AccountMenuStrip
            // 
            this.AccountMenuStrip.AutoSize = false;
            this.AccountMenuStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.AccountMenuStrip.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AccountMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.myAccountsToolStripMenuItem,
            this.userProfileToolStripMenuItem,
            this.transactionHistoryToolStripMenuItem,
            this.stToolStripMenuItem,
            this.financeNewsToolStripMenuItem,
            this.storeLocatorToolStripMenuItem,
            this.logOutToolStripMenuItem});
            this.AccountMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.AccountMenuStrip.Name = "AccountMenuStrip";
            this.AccountMenuStrip.Size = new System.Drawing.Size(759, 35);
            this.AccountMenuStrip.TabIndex = 3;
            // 
            // myAccountsToolStripMenuItem
            // 
            this.myAccountsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.myAccountsToolStripMenuItem.Name = "myAccountsToolStripMenuItem";
            this.myAccountsToolStripMenuItem.Size = new System.Drawing.Size(105, 31);
            this.myAccountsToolStripMenuItem.Text = "My Accounts";
            this.myAccountsToolStripMenuItem.Click += new System.EventHandler(this.myAccountsToolStripMenuItem_Click);
            // 
            // userProfileToolStripMenuItem
            // 
            this.userProfileToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.userProfileToolStripMenuItem.Name = "userProfileToolStripMenuItem";
            this.userProfileToolStripMenuItem.Size = new System.Drawing.Size(97, 31);
            this.userProfileToolStripMenuItem.Text = "User Profile";
            this.userProfileToolStripMenuItem.Click += new System.EventHandler(this.userProfileToolStripMenuItem_Click);
            // 
            // transactionHistoryToolStripMenuItem
            // 
            this.transactionHistoryToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.transactionHistoryToolStripMenuItem.Name = "transactionHistoryToolStripMenuItem";
            this.transactionHistoryToolStripMenuItem.Size = new System.Drawing.Size(147, 31);
            this.transactionHistoryToolStripMenuItem.Text = "Transaction History";
            this.transactionHistoryToolStripMenuItem.Click += new System.EventHandler(this.transactionHistoryToolStripMenuItem_Click);
            // 
            // stToolStripMenuItem
            // 
            this.stToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.stToolStripMenuItem.Name = "stToolStripMenuItem";
            this.stToolStripMenuItem.Size = new System.Drawing.Size(107, 31);
            this.stToolStripMenuItem.Text = "Stock Market";
            this.stToolStripMenuItem.Click += new System.EventHandler(this.stToolStripMenuItem_Click);
            // 
            // financeNewsToolStripMenuItem
            // 
            this.financeNewsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.financeNewsToolStripMenuItem.Name = "financeNewsToolStripMenuItem";
            this.financeNewsToolStripMenuItem.Size = new System.Drawing.Size(111, 31);
            this.financeNewsToolStripMenuItem.Text = "Finance News";
            this.financeNewsToolStripMenuItem.Click += new System.EventHandler(this.financeNewsToolStripMenuItem_Click);
            // 
            // storeLocatorToolStripMenuItem
            // 
            this.storeLocatorToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.storeLocatorToolStripMenuItem.Name = "storeLocatorToolStripMenuItem";
            this.storeLocatorToolStripMenuItem.Size = new System.Drawing.Size(110, 31);
            this.storeLocatorToolStripMenuItem.Text = "Store Locator";
            this.storeLocatorToolStripMenuItem.Click += new System.EventHandler(this.storeLocatorToolStripMenuItem_Click);
            // 
            // logOutToolStripMenuItem
            // 
            this.logOutToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            this.logOutToolStripMenuItem.Size = new System.Drawing.Size(72, 31);
            this.logOutToolStripMenuItem.Text = "Log out";
            this.logOutToolStripMenuItem.Click += new System.EventHandler(this.logOutToolStripMenuItem_Click);
            // 
            // TransactionsGroupBox
            // 
            this.TransactionsGroupBox.BackColor = System.Drawing.Color.White;
            this.TransactionsGroupBox.Controls.Add(this.amountTextBox);
            this.TransactionsGroupBox.Controls.Add(this.amountLabel);
            this.TransactionsGroupBox.Controls.Add(this.transactionErrorLabel);
            this.TransactionsGroupBox.Controls.Add(this.submitButton);
            this.TransactionsGroupBox.Controls.Add(this.toLabel);
            this.TransactionsGroupBox.Controls.Add(this.accountToComboBox);
            this.TransactionsGroupBox.Controls.Add(this.fromLabel);
            this.TransactionsGroupBox.Controls.Add(this.accountFromComboBox);
            this.TransactionsGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TransactionsGroupBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.TransactionsGroupBox.Location = new System.Drawing.Point(488, 49);
            this.TransactionsGroupBox.Name = "TransactionsGroupBox";
            this.TransactionsGroupBox.Size = new System.Drawing.Size(250, 251);
            this.TransactionsGroupBox.TabIndex = 4;
            this.TransactionsGroupBox.TabStop = false;
            this.TransactionsGroupBox.Text = "Transactions";
            // 
            // amountTextBox
            // 
            this.amountTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amountTextBox.ForeColor = System.Drawing.Color.Silver;
            this.amountTextBox.Location = new System.Drawing.Point(104, 106);
            this.amountTextBox.Name = "amountTextBox";
            this.amountTextBox.Size = new System.Drawing.Size(140, 24);
            this.amountTextBox.TabIndex = 8;
            this.amountTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.amountTextBox.MouseEnter += new System.EventHandler(this.amountTextBox_Enter);
            // 
            // amountLabel
            // 
            this.amountLabel.AutoSize = true;
            this.amountLabel.Location = new System.Drawing.Point(7, 106);
            this.amountLabel.Name = "amountLabel";
            this.amountLabel.Size = new System.Drawing.Size(91, 25);
            this.amountLabel.TabIndex = 7;
            this.amountLabel.Text = "Amount:";
            // 
            // transactionErrorLabel
            // 
            this.transactionErrorLabel.AutoSize = true;
            this.transactionErrorLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.transactionErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.transactionErrorLabel.Location = new System.Drawing.Point(22, 154);
            this.transactionErrorLabel.Name = "transactionErrorLabel";
            this.transactionErrorLabel.Size = new System.Drawing.Size(0, 16);
            this.transactionErrorLabel.TabIndex = 5;
            // 
            // submitButton
            // 
            this.submitButton.BackColor = System.Drawing.Color.RoyalBlue;
            this.submitButton.ForeColor = System.Drawing.Color.White;
            this.submitButton.Location = new System.Drawing.Point(68, 179);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(121, 42);
            this.submitButton.TabIndex = 4;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = false;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // toLabel
            // 
            this.toLabel.AutoSize = true;
            this.toLabel.Location = new System.Drawing.Point(7, 66);
            this.toLabel.Name = "toLabel";
            this.toLabel.Size = new System.Drawing.Size(43, 25);
            this.toLabel.TabIndex = 3;
            this.toLabel.Text = "To:";
            // 
            // accountToComboBox
            // 
            this.accountToComboBox.BackColor = System.Drawing.Color.White;
            this.accountToComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.accountToComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accountToComboBox.FormattingEnabled = true;
            this.accountToComboBox.Items.AddRange(new object[] {
            "Checking Account",
            "Savings Account"});
            this.accountToComboBox.Location = new System.Drawing.Point(56, 66);
            this.accountToComboBox.Name = "accountToComboBox";
            this.accountToComboBox.Size = new System.Drawing.Size(188, 26);
            this.accountToComboBox.TabIndex = 2;
            // 
            // fromLabel
            // 
            this.fromLabel.AutoSize = true;
            this.fromLabel.Location = new System.Drawing.Point(7, 30);
            this.fromLabel.Name = "fromLabel";
            this.fromLabel.Size = new System.Drawing.Size(73, 25);
            this.fromLabel.TabIndex = 1;
            this.fromLabel.Text = "From: ";
            // 
            // accountFromComboBox
            // 
            this.accountFromComboBox.BackColor = System.Drawing.Color.White;
            this.accountFromComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.accountFromComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accountFromComboBox.FormattingEnabled = true;
            this.accountFromComboBox.Items.AddRange(new object[] {
            "Checking Account",
            "Savings Account"});
            this.accountFromComboBox.Location = new System.Drawing.Point(86, 30);
            this.accountFromComboBox.Name = "accountFromComboBox";
            this.accountFromComboBox.Size = new System.Drawing.Size(158, 26);
            this.accountFromComboBox.TabIndex = 0;
            // 
            // loansLabel
            // 
            this.loansLabel.AutoSize = true;
            this.loansLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loansLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.loansLabel.Location = new System.Drawing.Point(6, 49);
            this.loansLabel.Name = "loansLabel";
            this.loansLabel.Size = new System.Drawing.Size(328, 18);
            this.loansLabel.TabIndex = 1;
            this.loansLabel.Text = "There are no loans associated with your account";
            // 
            // loansGroupBox
            // 
            this.loansGroupBox.Controls.Add(this.loansLabel);
            this.loansGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loansGroupBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.loansGroupBox.Location = new System.Drawing.Point(12, 276);
            this.loansGroupBox.Name = "loansGroupBox";
            this.loansGroupBox.Size = new System.Drawing.Size(448, 128);
            this.loansGroupBox.TabIndex = 2;
            this.loansGroupBox.TabStop = false;
            this.loansGroupBox.Text = "Loans";
            // 
            // fundsDataSet
            // 
            this.fundsDataSet.DataSetName = "FundsDataSet";
            this.fundsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // fundsBindingSource
            // 
            this.fundsBindingSource.DataMember = "Funds";
            this.fundsBindingSource.DataSource = this.fundsDataSet;
            // 
            // fundsTableAdapter
            // 
            this.fundsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.FundsTableAdapter = this.fundsTableAdapter;
            this.tableAdapterManager.UpdateOrder = FinalProject.FundsDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // recordDataSet
            // 
            this.recordDataSet.DataSetName = "RecordDataSet";
            this.recordDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // recordBindingSource
            // 
            this.recordBindingSource.DataMember = "Record";
            this.recordBindingSource.DataSource = this.recordDataSet;
            // 
            // recordTableAdapter
            // 
            this.recordTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.RecordTableAdapter = this.recordTableAdapter;
            this.tableAdapterManager1.UpdateOrder = FinalProject.RecordDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // AccountForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(759, 424);
            this.Controls.Add(this.loansGroupBox);
            this.Controls.Add(this.TransactionsGroupBox);
            this.Controls.Add(this.creditCardGourpBox);
            this.Controls.Add(this.BankAccountsGroupBox);
            this.Controls.Add(this.AccountMenuStrip);
            this.MainMenuStrip = this.AccountMenuStrip;
            this.Name = "AccountForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bank Account";
            this.Load += new System.EventHandler(this.AccountForm_Load);
            this.BankAccountsGroupBox.ResumeLayout(false);
            this.BankAccountsGroupBox.PerformLayout();
            this.creditCardGourpBox.ResumeLayout(false);
            this.creditCardGourpBox.PerformLayout();
            this.AccountMenuStrip.ResumeLayout(false);
            this.AccountMenuStrip.PerformLayout();
            this.TransactionsGroupBox.ResumeLayout(false);
            this.TransactionsGroupBox.PerformLayout();
            this.loansGroupBox.ResumeLayout(false);
            this.loansGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fundsDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fundsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.recordDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.recordBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox BankAccountsGroupBox;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox creditCardGourpBox;
        private System.Windows.Forms.MenuStrip AccountMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem myAccountsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userProfileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transactionHistoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem storeLocatorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logOutToolStripMenuItem;
        private System.Windows.Forms.Label savingsAccountLabel;
        private System.Windows.Forms.Label checkingAccountLabel;
        private System.Windows.Forms.Label checkingAccountBalanceLabel;
        private System.Windows.Forms.Label creditCardLabel;
        private System.Windows.Forms.GroupBox TransactionsGroupBox;
        private System.Windows.Forms.Label savingsAccountBalanceLabel;
        private System.Windows.Forms.ComboBox accountFromComboBox;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Label toLabel;
        private System.Windows.Forms.ComboBox accountToComboBox;
        private System.Windows.Forms.Label fromLabel;
        private System.Windows.Forms.ToolStripMenuItem stToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem financeNewsToolStripMenuItem;
        private System.Windows.Forms.Label transactionErrorLabel;
        private System.Windows.Forms.TextBox amountTextBox;
        private System.Windows.Forms.Label amountLabel;
        private System.Windows.Forms.Label loansLabel;
        private System.Windows.Forms.GroupBox loansGroupBox;
        private FundsDataSet fundsDataSet;
        private System.Windows.Forms.BindingSource fundsBindingSource;
        private FundsDataSetTableAdapters.FundsTableAdapter fundsTableAdapter;
        private FundsDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private RecordDataSet recordDataSet;
        private System.Windows.Forms.BindingSource recordBindingSource;
        private RecordDataSetTableAdapters.RecordTableAdapter recordTableAdapter;
        private RecordDataSetTableAdapters.TableAdapterManager tableAdapterManager1;
    }
}