﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class AccountForm : Form 
    {
        int transactionID;
        decimal checkingBal;
        decimal savingsBal;
        decimal amountTransferred = 0;
        GroupBox groupBox1;
        Label userAddress, phoneNumber, name, userName;

        string address = "https://www.google.ca/maps/place/Vanier+College" +
            "/@45.5144812,-73.6775208,549m/data=!3m2!1e3!4b1!4m5" +
            "!3m4!1s0x4cc91840f9cb4ca1:0xce7f12be3902472b!8m2!3d45.5144775!4d" +
            "-73.6753321";
        public AccountForm()
        {
            InitializeComponent();
        }

        private void myAccountsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form currentForm = Form.ActiveForm;
            if (currentForm.Name.Equals("AccountForm"))
            {
                BankAccountsGroupBox.Visible = true;
                creditCardGourpBox.Visible = true;
                loansGroupBox.Visible = true;
                TransactionsGroupBox.Visible = true;

                //groupBox1.Visible = false;
            }
            else
            {
                this.Hide();
                var account = new AccountForm();
                account.Closed += (s, args) => this.Close();
                account.Show();
            }

        }

        private void AccountForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'recordDataSet.Record' table. You can move, or remove it, as needed.
            this.recordTableAdapter.Fill(this.recordDataSet.Record);
            displaySavingsBalance();
            displayCheckingBalance();
            amountTextBox.Text = "$0.00";
        }

        public int TransactionID 
        {
            get
            {
                return transactionID;
            }
            set
            {
                transactionID = value;
            }
        }
        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBoxButtons buttonType = MessageBoxButtons.YesNoCancel;
            DialogResult warning = MessageBox.Show("                      " +
                "Return to login window?"
                , "Community Bank",buttonType);
            switch(warning)
            {
                case DialogResult.Yes:
                    LoginForm login = new LoginForm();
                    login.GetLabel.ForeColor = Color.Green;
                    login.GetLabel.Text = "Successfully logged out!";
                    this.Close();
                    login.Show();
                    break;

                case DialogResult.No:
                    Application.Exit();
                    break;
            }
        }

        private void userProfileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BankAccountsGroupBox.Visible = false;
            creditCardGourpBox.Visible = false;
            loansGroupBox.Visible = false;
            TransactionsGroupBox.Visible = false;

            AddGroupBoxAndLables();
        }

        private void AddGroupBoxAndLables()
        {
            groupBox1 = new GroupBox();
            groupBox1.SetBounds(60, 60, 650, 300);
            groupBox1.Text = "User Information";
            groupBox1.ForeColor = Color.FromArgb(0,192,0);
            groupBox1.Font = new Font("Microsoft Sans Serif", 16);
            this.Controls.Add(groupBox1);

            userAddress = new Label { Name = "userAddressLabel",
                Text = "User Address:\n" +
                "821Sainte Croix Ave, Saint-Laurent,\nQuebec H4L 3X9\n"};
            userAddress.AutoSize = true;
            userAddress.Location = new Point(45, 90);
            userAddress.ForeColor = Color.Black;
            userAddress.Font = new Font("Microsoft Sans serif", 11);
            groupBox1.Controls.Add(userAddress);

            userName = new Label { Name = "usernameLabel" , Text = "Username:\nVaniercollege@edu.vaniercollege.qc.ca"};
            userName.AutoSize = true;
            userName.ForeColor = Color.Black;
            userName.Font = new Font("Microsoft Sans serif", 11);
            userName.Location = new Point(45, 170);
            groupBox1.Controls.Add(userName);

            phoneNumber = new Label { Name = "phoneNumberLabel", Text = "phoneNummber:\n514-555-5555" };
            phoneNumber.AutoSize = true;
            phoneNumber.ForeColor = Color.Black;
            phoneNumber.Font = new Font("Microsoft Sans serif", 11);
            phoneNumber.Location = new Point(45, 230);
            groupBox1.Controls.Add(phoneNumber);

            name = new Label { Name = "nameLabel", Text = "Name:\nVanier College Saint-Laurent" };
            name.AutoSize = true;
            name.ForeColor = Color.Black;
            name.Font = new Font("Microsoft Sans serif", 11);
            name.Location = new Point(45, 40);
            groupBox1.Controls.Add(name);
        }

        public AccountForm GetAccountForm()
        {
            return this;
        }
        private void transactionHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //this.Hide();
            var transactionHistory = new TransactionHistoryForm();
            //transactionHistory.Closed += (s, args) => this.Close();
            transactionHistory.Show();
        }

        private void stToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("https://www.bnnbloomberg.ca/markets");
        }

        private void financeNewsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("https://www.bnnbloomberg.ca/");
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            checkingBal = (decimal)this.fundsTableAdapter.checkingBalance();
            savingsBal = (decimal)this.fundsTableAdapter.savingsBalance();
            Double n = 0;
            string amountTextBoxStr = amountTextBox.Text;
            bool isNumeric = Double.TryParse(amountTextBoxStr, out n);
            string fromSelected = accountFromComboBox.Text;
            string toSelected = accountToComboBox.Text;

            if(fromSelected.Equals(toSelected))
            {
                transactionErrorLabel.Text = "Account types must be different.";
            }
            else if(amountTextBoxStr.Length == 0)
            {
                transactionErrorLabel.Text = "Please enter an amount";
            }
            else if(isNumeric == false)
            {
                transactionErrorLabel.Text = "The amount has to be numeric";
            }
            else
            {
                double tempAmountTransaferred = Convert.ToDouble(amountTextBoxStr);

                if(tempAmountTransaferred <= 0)
                {
                    transactionErrorLabel.Text = 
                        "The amount must be above $0";
                }
                else
                {
                    amountTransferred = Convert.ToDecimal(amountTextBoxStr);
                    if(fromSelected.Equals("Checking Account"))
                    {
                        
                        if(amountTransferred > checkingBal)
                        {
                            transactionErrorLabel.Text ="Insufficient Funds!";
                        }
                        else
                        {
                            
                            checkingBal -= amountTransferred;
                            savingsBal += amountTransferred;
                            insertToDatabase();
                            displaySuccessfulTransaction();
                            
                        }
                    }
                    else
                    {
                        if (amountTransferred > savingsBal)
                        {
                            transactionErrorLabel.Text = "Insufficient Funds!";
                        }
                        else
                        {
                            
                            checkingBal += amountTransferred;
                            savingsBal -= amountTransferred;
                            insertToDatabase();
                            displaySuccessfulTransaction();
                            
                        }                       
                    }           
                }
            }
        }

        private void amountTextBox_Enter(object sender, EventArgs e)
        {
            if (amountTextBox.Text.Equals("$0.00"))
            {
                amountTextBox.Text = "";
                amountTextBox.ForeColor = Color.Black;
            }
        }
        private void displaySavingsBalance()
        {
            savingsBal = (decimal)this.fundsTableAdapter.savingsBalance();
            savingsAccountBalanceLabel.Text = savingsBal.ToString("C");
        }

        private void displayCheckingBalance()
        {
            checkingBal = (decimal)this.fundsTableAdapter.checkingBalance();
            checkingAccountBalanceLabel.Text = checkingBal.ToString("C");
        }

        private void storeLocatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start(address);
        }

        private void displaySuccessfulTransaction()
        {
            displayCheckingBalance();
            displaySavingsBalance();
            successForm success = new successForm();
            success.setsuccessLabelText("Success!");
            success.settextLabelText(amountTransferred.ToString("c") +
                " was tranferred from " + accountFromComboBox.Text +
                " to " + accountToComboBox.Text);
            success.ShowDialog();
        }
        private void insertToDatabase()
        {
            transactionErrorLabel.Text = " ";
            transactionID = (int)this.recordTableAdapter.getTransactionID() + 1;

            this.fundsTableAdapter.updateBalances(checkingBal, savingsBal);
            DateTime dt = DateTime.Now;
            this.recordTableAdapter.insertTransaction(accountFromComboBox.Text, 
                accountToComboBox.Text, amountTransferred.ToString("c"), dt);

            this.Validate();
            this.recordBindingSource.EndEdit();
            this.tableAdapterManager1.UpdateAll(this.recordDataSet);
            this.recordTableAdapter.Update(this.recordDataSet.Record);

            this.Validate();
            this.fundsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.fundsDataSet);
            //this.fundsTableAdapter.Update(this.fundsDataSet.Funds);
        }
    }
}
