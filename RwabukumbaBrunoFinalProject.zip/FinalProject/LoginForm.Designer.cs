﻿namespace FinalProject
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.usernameLabel = new System.Windows.Forms.Label();
            this.passwordLabel = new System.Windows.Forms.Label();
            this.userNameTextBox = new System.Windows.Forms.TextBox();
            this.passwordTextBox = new System.Windows.Forms.TextBox();
            this.logInButton = new System.Windows.Forms.Button();
            this.loginErrorLabel = new System.Windows.Forms.Label();
            this.loginImagePictureBox = new System.Windows.Forms.PictureBox();
            this.fundsDataSet = new FinalProject.FundsDataSet();
            this.fundsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fundsTableAdapter = new FinalProject.FundsDataSetTableAdapters.FundsTableAdapter();
            this.tableAdapterManager = new FinalProject.FundsDataSetTableAdapters.TableAdapterManager();
            this.credentialDataSet = new FinalProject.CredentialDataSet();
            this.credentialBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.credentialTableAdapter = new FinalProject.CredentialDataSetTableAdapters.CredentialTableAdapter();
            this.tableAdapterManager1 = new FinalProject.CredentialDataSetTableAdapters.TableAdapterManager();
            ((System.ComponentModel.ISupportInitialize)(this.loginImagePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fundsDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fundsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.credentialDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.credentialBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // usernameLabel
            // 
            this.usernameLabel.AutoSize = true;
            this.usernameLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernameLabel.Location = new System.Drawing.Point(222, 72);
            this.usernameLabel.Name = "usernameLabel";
            this.usernameLabel.Size = new System.Drawing.Size(82, 19);
            this.usernameLabel.TabIndex = 0;
            this.usernameLabel.Text = "Username:";
            // 
            // passwordLabel
            // 
            this.passwordLabel.AutoSize = true;
            this.passwordLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordLabel.Location = new System.Drawing.Point(228, 111);
            this.passwordLabel.Name = "passwordLabel";
            this.passwordLabel.Size = new System.Drawing.Size(77, 19);
            this.passwordLabel.TabIndex = 1;
            this.passwordLabel.Text = "Password:";
            // 
            // userNameTextBox
            // 
            this.userNameTextBox.Location = new System.Drawing.Point(302, 73);
            this.userNameTextBox.Name = "userNameTextBox";
            this.userNameTextBox.Size = new System.Drawing.Size(172, 20);
            this.userNameTextBox.TabIndex = 2;
            // 
            // passwordTextBox
            // 
            this.passwordTextBox.Location = new System.Drawing.Point(302, 112);
            this.passwordTextBox.Name = "passwordTextBox";
            this.passwordTextBox.Size = new System.Drawing.Size(172, 20);
            this.passwordTextBox.TabIndex = 3;
            this.passwordTextBox.UseSystemPasswordChar = true;
            // 
            // logInButton
            // 
            this.logInButton.BackColor = System.Drawing.Color.RoyalBlue;
            this.logInButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logInButton.ForeColor = System.Drawing.Color.White;
            this.logInButton.Location = new System.Drawing.Point(383, 145);
            this.logInButton.Name = "logInButton";
            this.logInButton.Size = new System.Drawing.Size(91, 32);
            this.logInButton.TabIndex = 5;
            this.logInButton.Text = "Log in";
            this.logInButton.UseVisualStyleBackColor = false;
            this.logInButton.Click += new System.EventHandler(this.logInButton_Click);
            // 
            // loginErrorLabel
            // 
            this.loginErrorLabel.AutoSize = true;
            this.loginErrorLabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.loginErrorLabel.Location = new System.Drawing.Point(252, 38);
            this.loginErrorLabel.Name = "loginErrorLabel";
            this.loginErrorLabel.Size = new System.Drawing.Size(0, 25);
            this.loginErrorLabel.TabIndex = 6;
            // 
            // loginImagePictureBox
            // 
            this.loginImagePictureBox.Image = global::FinalProject.Properties.Resources.dollar1;
            this.loginImagePictureBox.Location = new System.Drawing.Point(30, 17);
            this.loginImagePictureBox.Name = "loginImagePictureBox";
            this.loginImagePictureBox.Size = new System.Drawing.Size(167, 218);
            this.loginImagePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.loginImagePictureBox.TabIndex = 4;
            this.loginImagePictureBox.TabStop = false;
            // 
            // fundsDataSet
            // 
            this.fundsDataSet.DataSetName = "FundsDataSet";
            this.fundsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // fundsBindingSource
            // 
            this.fundsBindingSource.DataMember = "Funds";
            this.fundsBindingSource.DataSource = this.fundsDataSet;
            // 
            // fundsTableAdapter
            // 
            this.fundsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.FundsTableAdapter = this.fundsTableAdapter;
            this.tableAdapterManager.UpdateOrder = FinalProject.FundsDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // credentialDataSet
            // 
            this.credentialDataSet.DataSetName = "CredentialDataSet";
            this.credentialDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // credentialBindingSource
            // 
            this.credentialBindingSource.DataMember = "Credential";
            this.credentialBindingSource.DataSource = this.credentialDataSet;
            // 
            // credentialTableAdapter
            // 
            this.credentialTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.CredentialTableAdapter = this.credentialTableAdapter;
            this.tableAdapterManager1.UpdateOrder = FinalProject.CredentialDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(597, 264);
            this.Controls.Add(this.loginErrorLabel);
            this.Controls.Add(this.logInButton);
            this.Controls.Add(this.loginImagePictureBox);
            this.Controls.Add(this.passwordTextBox);
            this.Controls.Add(this.userNameTextBox);
            this.Controls.Add(this.passwordLabel);
            this.Controls.Add(this.usernameLabel);
            this.Name = "LoginForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Community Bank ";
            this.Load += new System.EventHandler(this.LoginForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.loginImagePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fundsDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fundsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.credentialDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.credentialBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label usernameLabel;
        private System.Windows.Forms.Label passwordLabel;
        private System.Windows.Forms.TextBox userNameTextBox;
        private System.Windows.Forms.TextBox passwordTextBox;
        private System.Windows.Forms.PictureBox loginImagePictureBox;
        private System.Windows.Forms.Button logInButton;
        private System.Windows.Forms.Label loginErrorLabel;
        private FundsDataSet fundsDataSet;
        private System.Windows.Forms.BindingSource fundsBindingSource;
        private FundsDataSetTableAdapters.FundsTableAdapter fundsTableAdapter;
        private FundsDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private CredentialDataSet credentialDataSet;
        private System.Windows.Forms.BindingSource credentialBindingSource;
        private CredentialDataSetTableAdapters.CredentialTableAdapter credentialTableAdapter;
        private CredentialDataSetTableAdapters.TableAdapterManager tableAdapterManager1;
    }
}

