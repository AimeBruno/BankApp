﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        public Label GetLabel
        {
            get
            {
                return this.loginErrorLabel;
            }
            set
            {
                this.loginErrorLabel = value;
            }
        }

        private void logInButton_Click(object sender, EventArgs e)
        {
            
                string userName = userNameTextBox.Text;
                string password = this.credentialTableAdapter.getPassword(userName);
                bool isValidUsername = this.credentialTableAdapter.usernameSearch(userName) > 0;
                if((isValidUsername == false || !passwordTextBox.Text.Equals(password))
                    || (userNameTextBox.Text.Length == 0
                || passwordTextBox.Text.Length == 0))
                {
                loginErrorLabel.ForeColor = Color.Red;
                    loginErrorLabel.Text = "Incorrect credentials!";
                }
                else
                {
                    loginErrorLabel.Text = " ";
                    AccountForm bankAccount = new AccountForm();
                    bankAccount.Show();
                    this.Hide();
                }
            
        }
        private void fundsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.fundsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.fundsDataSet);

        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'credentialDataSet.Credential' table. You can move, or remove it, as needed.
            this.credentialTableAdapter.Fill(this.credentialDataSet.Credential);
            // TODO: This line of code loads data into the 'fundsDataSet.Funds' table. You can move, or remove it, as needed.
            this.fundsTableAdapter.Fill(this.fundsDataSet.Funds);

        }
    }
}
