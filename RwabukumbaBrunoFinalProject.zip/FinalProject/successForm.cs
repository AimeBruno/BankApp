﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class successForm : Form
    {
        public successForm()
        {
            InitializeComponent();
        }

        public void setsuccessLabelText(string text)
        {
            successLabel.Text = text;
        }

        public void settextLabelText(string text)
        {
            textLabel.Text = text;
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
